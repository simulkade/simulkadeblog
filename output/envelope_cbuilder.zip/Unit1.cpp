//---------------------------------------------------------------------------

#include <vcl.h>
#include <vector.h>
#include <deque>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------

int NN;
deque <long double> Tc(3),Pc(3),w(3);

//---------------------------------------------------------------------------
void tomas(deque < deque <double> > coeff, deque <double> *result1 ,int nn)
   {
     int i,j;
     deque < deque <double> > coeff1;
     deque <double> temp1;
     coeff1=coeff;
     temp1.resize(nn);
     for(i=1;i<=nn-1;i++)
       {
         coeff1[i][0]=coeff1[i][0]/coeff1[i-1][1];
         coeff1[i][1]=coeff1[i][1]-coeff1[i][0]*coeff1[i-1][2];
         coeff1[i][3]=coeff1[i][3]-coeff1[i][0]*coeff1[i-1][3];
       }
     coeff1[nn-1][3]=coeff1[nn-1][3]/coeff1[nn-1][1];
     for(i=nn-2;i>=0;i--)
       coeff1[i][3]=(coeff1[i][3]-coeff1[i][2]*coeff1[i+1][3])/coeff1[i][1];
     for(i=0;i<=nn-1;i++)
       temp1[i]=coeff1[i][3];
     *result1=temp1;  
   }
//----------------------------------------------------------------------------
   long double sum(deque <long double> a, int n)
     {
     long double ss;
     int i;
     ss=0.0;
     for(i=0;i<=n;i++)
       ss=ss+a[i];
     return ss;
     }
//---------------------------------------------------------------------------
 void root_find(long double rr, long double ss, long double *x1,
                long double *x2, long double *y1, long double *y2)
     {
     long double delta;
     delta=rr*rr+4.0*ss;
     if(delta>=0)
       {
       *x1=(rr+sqrtl(delta))/2.0;
       *x2=(rr-sqrtl(delta))/2.0;
       *y1=0;
       *y2=0;
       }
     else
       {
         *x1=rr/2.0;
         *x2=rr/2.0;
         *y1=sqrtl(-delta)/2.0;
         *y2=-sqrtl(-delta)/2.0;
       }

   }
//--------------------------------------------------------------------------
  void normalize(deque <long double> *a, int n)
    {
    long double ss;
    deque <long double> a1;
    int i;
    a1=*a;
    ss=sum(a1,n);
    for(i=0;i<=n;i++)
      a1[i]=a1[i]/ss;
    *a=a1;
    }
//----------------------------------------------------------------------------
 void cubic_spline(deque <double> x, deque <double> y,
              deque < deque <double> > *poly_coef, int condition, int leng)
     {
     int i,n;
     deque <double> s,s1,h;
     deque <deque <double> > a,a1;
     n=leng;
     s.resize(n);
     h.resize(n-1);
     a.resize(n-2);
     s1.resize(n-2);
     a1.resize(n-1);
     for(i=0;i<=n-2;i++)
       a1[i].resize(4);
     for(i=0;i<=n-3;i++)
       a[i].resize(4);
     n=n-1;
     for(i=0;i<=n-1;i++)
       h[i]=x[i+1]-x[i];
     for(i=1;i<=n-3;i++)
       {
         a[i][0]=(h[i]);
         a[i][1]=(2.0*(h[i]+h[i+1]));
         a[i][2]=(h[i+1]);
         a[i][3]=(6.0*((y[i+2]-y[i+1])/h[i+1]-(y[i+1]-y[i])/h[i]));
       }
     a[0][3]=6*((y[2]-y[1])/h[1]-(y[1]-y[0])/h[0]);
     a[n-2][3]=6*((y[n]-y[n-1])/h[n-1]-(y[n-1]-y[n-2])/h[n-2]);
     a[0][0]=0;
     a[n-2][2]=0;

     if(condition==1){ //case
           a[0][1]=2*(h[0]+h[1]);
           a[0][2]=h[1];
           a[n-2][0]=h[n-2];
           a[n-2][1]=2*(h[n-2]+h[n-1]);
           s[0]=0;
           s[n]=0;
       }
      else if(condition==3){
           a[0][1]=3*h[0]+2*h[1];
           a[0][2]=h[1];
           a[n-2][0]=h[n-2];
           a[n-2][1]=2*h[n-2]+3*h[n-1];
         }

     else if(condition==4){
           a[0][1]=(h[0]+h[1])*(h[0]+2*h[1])/h[1];
           a[0][2]=(pow(h[1],2)-pow(h[0],2))/h[1];
           a[n-2][0]=(pow(h[n-2],2)-pow(h[n-1],2))/h[n-2];
           a[n-2][1]=(h[n-1]+h[n-2])*(h[n-1]+2*h[n-2])/h[n-2];
         }
      tomas(a,&s1,n-1);
      for(i=0;i<=n-2;i++)
        s[i+1]=s1[i];
      if(condition==3){
            s[0]=s[1];
            s[n]=s[n-1];
         }
      else if(condition==4){
            s[0]=((h[0]+h[1])*s[1]-h[0]*s[2])/h[1];
            s[n]=((h[n-2]+h[n-1])*s[n-1]-h[n-1]*s[n-2])/h[n-2];
         }
      for(i=0;i<=n-1;i++)
        {
          a1[i][0]=(s[i+1]-s[i])/(6*h[i]);
          a1[i][1]=s[i]/2.0;
          a1[i][2]=(y[i+1]-y[i])/h[i]-(2*h[i]*s[i]+h[i]*s[i+1])/6;
          a1[i][3]=y[i];
        }
      *poly_coef=a1;
   }

//--------------------------------------------------------------------------
 void findmaxmin(deque <long double> numbers, deque <long double> img_nom, long double *max_no,
                 long double *min_no)
   {
   int i;
   long double ma,mi;
   for(i=0;i<=2;i++)
     {
       if ((numbers[i]>0) && (img_nom[i]==0))
         {
           ma=numbers[i];
           mi=numbers[i];
         }
     }

   for(i=0;i<=2;i++)
     {
       if ((numbers[i]>ma) && (numbers[i]>0) && (img_nom[i]==0))
         ma=numbers[i];
       if ((numbers[i]<mi) && (numbers[i]>0) && (img_nom[i]==0))
         mi=numbers[i];
     }
   *max_no=ma;
   *min_no=mi;
 }
//--------------------------------------------------------------------------
void bairstow(deque <long double> a1, deque <long double> *real_result,
              deque <long double> *img_result, int NP)
   {
   deque <long double> a,b,c,result1,result2;
   long double ds,dr,r,s,eps,x1,y1,x2,y2;
   int i,j,itr,N;
     N=NP;
     b.resize(N+1);
     c.resize(N+1);
     result1.resize(N);
     result2.resize(N);
     a=a1;
     j=0;
     itr=0;
     r=-1.0;
     s=-1.0;
     eps=0.0001;
   while(N>2)
   {
     b[1]=1;
     itr=0;
     while ((fabsl(b[1])>eps) || (fabsl(b[0])>eps) && (itr<1500))
     {
       b[N]=a[N];
       b[N-1]=a[N-1]+r*b[N];
       for(i=N;i>=2;i--)
         b[i-2]=a[i-2]+r*b[i-1]+s*b[i];
       c[N]=b[N];
       c[N-1]=b[N-1]+r*c[N];
       for(i=N;i>=3;i--)
         c[i-2]=b[i-2]+r*c[i-1]+s*c[i];
       dr=(-c[2]*b[1]+c[3]*b[0])/(c[2]*c[2]-c[1]*c[3]);
       ds=(-c[2]*b[0]+c[1]*b[1])/(c[2]*c[2]-c[3]*c[1]);
       r=r+dr;
       s=s+ds;
       itr=itr+1;
     }
     for(i=N;i>=2;i--)
       a[i-2]=b[i];
     root_find(r,s,&x1,&y1,&x2,&y2);
     result1[j]=x1;
     result1[j+1]=y1;
     result2[j]=x2;
     result2[j+1]=y2;
     N=N-2;
     j=j+2;

   }
     if (N==2)
       {
         root_find(-a[1]/a[2],-a[0]/a[2],&x1,&y1,&x2,&y2);
         result1[j]=x1;
         result1[j+1]=y1;
         result2[j]=x2;
         result2[j+1]=y2;
       }
     else
       {
         result1[j]=-a[0]/a[1];
         result2[j]=0.0;
       }
     *real_result=result1;
     *img_result=result2;
   }
//---------------------------------------------------------------------------
 void peng_robinson(deque <long double> x, long double p, long double t,
               deque <long double> *fugacity, int phase1)
   {

      int i,j,N;
      deque <long double> Tr,Pr,ai,bi,aci,alfa,alfai,mi,Abar,fugacity1;
      long double A_coef,B_coef,R,a,b,part1,part2,part3,zz,zl,zv;
      deque <long double> poly_coef(4);
      deque <long double> real_part(3),img_part(3);
      bool cond;
     N=NN;
     ai.resize(N);  bi.resize(N);
     aci.resize(N);  mi.resize(N);
     alfai.resize(N);  alfa.resize(N);
     Tr.resize(N);   ai.resize(N);
     Abar.resize(N);  fugacity1.resize(N);

     R=8.314e-5;
   b=0.0;
   for(i=0;i<=N-1;i++)
     {
       bi[i]=0.08664*R*Tc[i]/Pc[i];
       b=b+bi[i]*x[i];
       aci[i]=0.42748*powl((R*Tc[i]),2.0)/Pc[i];
       mi[i]=0.48+(1.574-0.176*w[i])*w[i];
       Tr[i]=t/Tc[i];
       alfai[i]=1.0+mi[i]*(1.0-powl(Tr[i],0.5));
       alfa[i]=powl(alfai[i],2.0);
       ai[i]=aci[i]*alfa[i];
     }
   a=0.0;
   for(i=0;i<=N-1;i++)
     for(j=0;j<=N-1;j++)
       a=a+x[i]*x[j]*powl((ai[i]*ai[j]),0.5);
   A_coef=a*p/powl((R*t),2.0);
   B_coef=b*p/(R*t);
   poly_coef[0]=-A_coef*B_coef;
   poly_coef[1]=A_coef-B_coef*(1+B_coef);
   poly_coef[2]=-1.0;
   poly_coef[3]=1.0;
   bairstow(poly_coef,&real_part,&img_part,3);
   findmaxmin(real_part,img_part,&zv,&zl);
   if(phase1==1)
      zz=zl;
   else if(phase1==2)
      zz=zv;
   for(i=0;i<=N-1;i++)
     {
       part1=bi[i]/b*(zz-1.0)-logl(fabsl(zz-b*p/(R*t)));
       part2=0.0;
       for(j=0;j<=N-1;j++)
           part2=part2+x[j]*powl((ai[i]*ai[j]),0.5);
       part3=A_coef/B_coef*(bi[i]/b-2.0/a*part2)*logl(1.0+b*p/(R*t*zz));
       fugacity1[i]=expl(part1+part3);
     }
   *fugacity=fugacity1;     
   }

//*************************************************************
 void flash_calc(deque <long double> composition, long double T, long double P,
                 deque <long double> *y, deque <long double> *x,
                 long double *noo, long double eps, int max_itr)
    {
    int i,j,N;
    long double error1,error2,error3,f,dfdv,vapor_frac;
    deque <long double> ki,liq_fug,vap_fug,liquid_x,vapor_y;
  try
   {
    N=NN;
    ki.resize(N);  liq_fug.resize(N);
    vap_fug.resize(N);    liquid_x.resize(N);
    vapor_y.resize(N);
    for(i=0;i<=N-1;i++)
      ki[i]=Pc[i]/P*expl(5.37*(1+w[i])*(1-Tc[i]/T));

    vapor_frac=0.5;
    error1=1.0;
    j=0;
   while ((error1>eps) || (error2>eps) || (error3>eps))
   {
    j=j+1;
    if (j>max_itr)
      break;
    f=0.0;
    dfdv=0.0;
    for(i=0;i<=N-1;i++)
      if (composition[i]!=0)
        {
          f=f+composition[i]*(ki[i]-1)/(1+vapor_frac*(ki[i]-1));
          dfdv=dfdv-composition[i]*powl(ki[i]-1.0,2)/powl(1.0+vapor_frac*(ki[i]-1.0),2);
        }
    vapor_frac=vapor_frac-f/dfdv;
    if(vapor_frac<0)
      vapor_frac=0;
    if(vapor_frac>1)
      vapor_frac=1;
    for(i=0;i<=N-1;i++)
      {
        liquid_x[i]=composition[i]/(1+vapor_frac*(ki[i]-1));
        vapor_y[i]=ki[i]*liquid_x[i];
      }
    error1=fabsl(sum(liquid_x,N-1)-1.0);
    error2=fabsl(sum(vapor_y,N-1)-1.0);
    error3=fabsl(f/dfdv);
    if(fabsl(dfdv)<eps*1e-5)
      error3=f;
    normalize(&liquid_x,N-1);
    normalize(&vapor_y,N-1);
    peng_robinson(liquid_x,P,T,&liq_fug,1);
    peng_robinson(vapor_y,P,T,&vap_fug,2);
    for(i=0;i<=N-1;i++)
      if (composition[i]!=0)
        ki[i]=liq_fug[i]/vap_fug[i];
  }
  if ((vapor_frac==0) || (vapor_frac==1))
    {
      vapor_y=composition;
      liquid_x=composition;
    }
  *x=liquid_x;
  *y=vapor_y;
  *noo=vapor_frac;
}
__finally
{
}
  }
//---------------------------------------------------------------------------

void Bubble(deque <long double> composition, long double t, deque <long double> *y,
            long double *p, long double eps)
   {
   int i,j,N;
   long double p_temp,sum_y,error1,sum_y_temp,bubble_p1,bubble_p;
   deque <long double> ki,liq_fug,vap_fug,bubble_y;
   N=NN;
   ki.resize(N);  liq_fug.resize(N);
   vap_fug.resize(N);  bubble_y.resize(N);
   j=0;
   bubble_p=*p;
   for(i=0;i<=N-1;i++)
     {
       ki[i]=Pc[i]/bubble_p*expl(5.37*(1+w[i])*(1.0-Tc[i]/t));
       bubble_y[i]=ki[i]*composition[i];
     }
   p_temp=*p;
   sum_y_temp=sum(bubble_y,N-1);

   normalize(&bubble_y,N-1);


   peng_robinson(composition,bubble_p,t,&liq_fug,1);
   peng_robinson(bubble_y,bubble_p,t,&vap_fug,2);
   for(i=0;i<=N-1;i++)
       {
         ki[i]=liq_fug[i]/vap_fug[i];
         bubble_y[i]=ki[i]*composition[i];
       }
    sum_y=sum(bubble_y,N-1);
    error1=fabsl(sum_y-1.0);
    bubble_p=1.05*bubble_p;
    normalize(&bubble_y,N-1);
    j=0;
   while (error1>eps)
   {
     peng_robinson(composition,bubble_p,t,&liq_fug,1);
     peng_robinson(bubble_y,bubble_p,t,&vap_fug,2);
     for(i=0;i<=N-1;i++)
       {
         ki[i]=liq_fug[i]/vap_fug[i];
         bubble_y[i]=ki[i]*composition[i];
       }
     sum_y=sum(bubble_y,N-1);
     error1=fabsl(sum_y-1.0);
     j=j+1;
     bubble_p1=(1.0-sum_y_temp)*(bubble_p-p_temp)/(sum_y-sum_y_temp)+p_temp;
     p_temp=bubble_p;
     bubble_p=bubble_p1;
     sum_y_temp=sum_y;
     normalize(&bubble_y,N-1);
     if(j>500) return;
   }
   *p=bubble_p;
   *y=bubble_y;
}
//---------------------------------------------------------------------------
void Dew(deque <long double> composition, long double t, deque <long double> *x,
         long double *p, long double eps)
     {
     int i,j,N;
     long double p_temp,sum_x,error1,sum_x_temp,dew_p1,dew_p;
     deque <long double> ki,liq_fug,vap_fug,dew_x;
     N=NN;
     ki.resize(N);  liq_fug.resize(N);
     vap_fug.resize(N);  dew_x.resize(N);
     j=0;
     dew_p=*p;
     for(i=0;i<=N-1;i++)
       {
         ki[i]=Pc[i]/dew_p*expl(5.37*(1+w[i])*(1-Tc[i]/t));
         dew_x[i]=composition[i]/ki[i];
       }
     p_temp=dew_p;
     sum_x_temp=sum(dew_x,N-1);

   normalize(&dew_x,N-1);


   peng_robinson(dew_x,dew_p,t,&liq_fug,1);
   peng_robinson(composition,dew_p,t,&vap_fug,2);
   for(i=0;i<=N-1;i++)
       {
         ki[i]=liq_fug[i]/vap_fug[i];
         dew_x[i]=composition[i]/ki[i];
       }
    sum_x=sum(dew_x,N-1);
    error1=fabsl(sum_x-1.0);
    dew_p=1.05*dew_p;
    normalize(&dew_x,N-1);
    j=0;
   while (error1>eps)
   {
     peng_robinson(dew_x,dew_p,t,&liq_fug,1);
     peng_robinson(composition,dew_p,t,&vap_fug,2);
     for(i=0;i<=N-1;i++)
       {
         ki[i]=liq_fug[i]/vap_fug[i];
         dew_x[i]=composition[i]/ki[i];
       }
     sum_x=sum(dew_x,N-1);
     error1=fabsl(sum_x-1.0);
     j=j+1;
     /*dew_p1=(1.0-sum_x_temp)*(dew_p-p_temp)/(sum_x-sum_x_temp)+p_temp;
     p_temp=dew_p;
     dew_p=dew_p1;
     sum_x_temp=sum_x;*/
     dew_p=dew_p/sum_x;
     normalize(&dew_x,N-1);
     if(j>500) return;
   }
   *x=dew_x;
   *p=dew_p;
  }

//---------------------------------------------------------------------------
void vapor_frac(long double t, long double v, deque <long double> z, deque <long double> *xx,
            deque <long double> *yy, long double *pp)
  {
    bool error1;
    long double p1,p2,p,v1;
    deque <long double> x,y;
    x.resize(NN);
    y.resize(NN);
    p1=1.0;
    p2=*pp;
    error1=true;
    while (error1)
    {
      p=(p1+p2)/2.0;
      flash_calc(z,t,p,&y,&x,&v1,1e-4,100);
      if (v1>v)
        p1=p;
      else if (v1<v)
        p2=p;
      else if (v1==v)
        break;
      if (fabsl(v1-v)<0.00001)
        break;
      else if (fabsl(p1-p2)<0.000001)
        {
          p=0;
          break;
        }
    }
    *pp=p;
    *yy=y;
    *xx=x;
  }
//---------------------------------------------------------------------------


__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
int i,j,k;
deque <long double> z(3),x(3),y(3);
deque <double> x1(11),y1(11);
deque < deque <double> > interp1;
long double jj,p,pp,t,t1,t2,dt1,dt2,t_bubble,t_dew,p_bub,p_dew,noo,temp1,temp2;
bool bool1;

Tc[0]=190.7;     Pc[0]=46.41;   w[0]=0.0115;
Tc[1]=305.43;    Pc[1]=48.84;   w[1]=0.0986;
Tc[2]=568.6;     Pc[2]=24.97;   w[2]=0.4018;
z[0]=0.1;
z[1]=0.15;
z[2]=0.75;
NN=3;
p=2.0;
bool1=true;
p_bub=3.0;
p_dew=3.0;
t_dew=412.0;
t_bubble=163.0;

t1=t_bubble;
t2=t_dew;
dt1=5.0;
dt2=5.0;
bool1=true;
i=1;
try
{
  while(bool1)
  {
    i=i+1;
    t1=t1+dt1;
    if(t1>550)
      break;
    Bubble(z,t1,&y,&p_bub,0.0001);
    flash_calc(z,t1,p_bub,&y,&x,&noo,0.00001,50);
    if(noo>0.1)
      break;
    pp=p_bub;
    vapor_frac(t1,0.05,z,&x,&y,&pp);
    if(pp!=0.0)
      Series4->AddXY(t1,pp,"",clTeeColor);
    pp=p_bub;
    vapor_frac(t1,0.2,z,&x,&y,&pp);
    if(pp!=0.0)
      Series5->AddXY(t1,pp,"",clTeeColor);
    pp=p_bub;
    vapor_frac(t1,0.4,z,&x,&y,&pp);
    if(pp!=0.0)
      Series6->AddXY(t1,pp,"",clTeeColor);
    stringgrid1->RowCount=i+1;
    stringgrid1->Cells[0][i]=FloatToStr(i);
    stringgrid1->Cells[1][i]=FloatToStr(t1-273.15);
    stringgrid1->Cells[2][i]=FloatToStr(p_bub);
    Series1->AddXY(t1,p_bub,"",clTeeColor);
  }
}
__finally
{
k=0;
for(j=i-5;j<=i-1;j++)
  {
    x1[k]=StrToFloat(stringgrid1->Cells[2][j]);
    y1[k]=StrToFloat(stringgrid1->Cells[1][j])+273.15;
    k=k+1;
  }
}
i=1;
try
{
  while(bool1)
  {
    i=i+1;
    t2=t2+dt2;
    if(t2>550.0)
      break;
    Dew(z,t2,&x,&p_dew,0.0001);
    flash_calc(z,t2,p_dew,&y,&x,&noo,0.00001,50);
    if((noo<0.999) || (p_dew==0.0)) break;
    stringgrid1->RowCount=i+1;
    stringgrid1->Cells[3][i]=FloatToStr(t2-273.15);
    stringgrid1->Cells[4][i]=FloatToStr(p_dew);
    Series2->AddXY(t2,p_dew,"",clTeeColor);

  }
}
__finally
{
for(j=i-1;j>=i-6;j--)
  {
    x1[k]=StrToFloat(stringgrid1->Cells[4][j]);
    y1[k]=StrToFloat(stringgrid1->Cells[3][j])+273.15;
    k=k+1;
  }
}
interp1.resize(10);
for(i=0;i<=9;i++)
  interp1[i].resize(4);
cubic_spline(x1,y1,&interp1,3,11);
stringgrid1->RowCount=i+2;
for(i=1;i<=30;i++)
  {
    temp1=0.0;
    temp2=(x1[5]-x1[4])/30.0;
    jj=3;
    for(j=3;j>=0;j--){
      jj-=1.0;
      temp1=interp1[4][3-j]*powl(1.0*i*temp2,1.0*j)+temp1;
    }
    Series3->AddXY(temp1,x1[4]+1.0*i*temp2,"",clTeeColor);
  }
}
//--------------------------------------------------------------------------

